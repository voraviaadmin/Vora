import express from "express";
import { requireSyncMode } from "../../middleware/resolveContext";

export function restaurantsRouter() {
  const router = express.Router();

  function meta(req: any) {
    const mode = req?.ctx?.profileMode ?? "privacy";
    const syncMode = !!req?.ctx?.syncEnabled;
    const requestId = req?.ctx?.requestId ?? req?.id;
    return { mode, syncMode, requestId };
  }


  function ok(req: any, data: any) {
    return { meta: meta(req), data };
  }
  
  function bad(req: any, code: string, message: string, action: string, status = 400) {
    return {
      status,
      body: {
        meta: meta(req),
        error: { code, message, action, retryable: false },
      },
    };
  }
  
  // confidence policy constants (keep centralized)
  const CONF = {
    HIGH: 0.8,
    MED: 0.5,
  };




  // GET /v1/restaurants/search?q=...
  router.get("/search", (req, res) => {
    const q = String(req.query.q ?? "").trim();
    if (!q) {
      return res.status(400).json({ meta: meta(req), error: "MISSING_QUERY" });
    }

    // v1 stub: return empty (UI wiring first)
    return res.json({
      meta: meta(req),
      data: { results: [] },
    });
  });


// POST /v1/restaurants/menu/ingest  (Phase 1)
// Accepts: menu_url OR menu_text OR items[]
router.post("/menu/ingest", (req, res) => {
  const mode: "privacy" | "sync" = req?.ctx?.profileMode ?? "privacy";

  // Hard rule: ingestion can exist in privacy mode ONLY as non-personalized parsing,
  // but scoring/ranking must be sync-only. (Keeps UX helpful without profile data.)
  const menu_url = typeof req.body?.menu_url === "string" ? req.body.menu_url.trim() : "";
  const menu_text = typeof req.body?.menu_text === "string" ? req.body.menu_text.trim() : "";
  const items = Array.isArray(req.body?.items) ? req.body.items : [];

  if (!menu_url && !menu_text && !items.length) {
    const r = bad(req, "MISSING_MENU_INPUT", "Provide a menu URL, menu text, or menu items.", "Paste a URL or upload a menu.");
    return res.status(r.status).json(r.body);
  }

  // Phase 1 stub normalization: return items if provided, else empty list.
  // (We will plug in Google fetch + parsing via provider adapter next.)
  const normalized = {
    source: menu_url ? "url" : menu_text ? "text" : "items",
    menuUrl: menu_url || null,
    items: items.map((it: any, idx: number) => ({
      itemId: String(it.itemId ?? `item-${idx}`),
      name: String(it.name ?? "").trim(),
      description: String(it.description ?? "").trim(),
      price: it.price ?? null,
    })),
    parseConfidence: items.length ? 0.85 : 0.5,
    notes: items.length
      ? ["Menu items accepted as-is."]
      : ["Menu parsing is not wired yet. Phase 1: URL/text parsing coming next."],
  };

  return res.json(ok(req, { normalized, modeHint: mode }));
});


// POST /v1/restaurants/menu/score  (Phase 1 scoring - SYNC ONLY)
router.post("/menu/score", (req, res) => {
  const mode: "privacy" | "sync" = req?.ctx?.profileMode ?? "privacy";
  if (mode !== "sync") {
    return res.status(403).json({
      meta: meta(req),
      error: {
        code: "MODE_BLOCKED",
        message: "Personalized menu scoring requires Sync Mode.",
        action: "Enable Sync in Profile to score menus.",
        retryable: false,
      },
    });
  }

  const items = Array.isArray(req.body?.items) ? req.body.items : [];
  if (!items.length) {
    const r = bad(req, "MISSING_ITEMS", "No menu items provided to score.", "Upload a menu or select items.");
    return res.status(r.status).json(r.body);
  }

  // Phase 1 stub scoring (replace later with AI provider)
  const ranked = items.map((it: any, idx: number) => ({
    itemId: String(it.itemId ?? `item-${idx}`),
    name: String(it.name ?? "").trim(),
    score: {
      value: 75,
      label: "Good",
      kind: "personalized",
    },
    confidence: 0.7,
    why: [
      "Personalized scoring engine will be connected to profile goals + AI provider next.",
      "This is a placeholder score to validate UX wiring.",
    ],
    safeFallback: {
      shown: false,
      reason: null,
    },
  }));

  return res.json(ok(req, { ranked }));
});












  // POST /v1/restaurants/score-items
  router.post("/score-items", (req, res) => {
    const mode: "privacy" | "sync" = req?.ctx?.profileMode ?? "privacy";
    const items = Array.isArray(req.body?.items) ? req.body.items : [];

    if (!items.length) {
      return res.status(400).json({ meta: meta(req), error: "MISSING_ITEMS" });
    }

    const ranked = items.map((it: any) => ({
      itemId: String(it.itemId ?? ""),
      score: {
        value: mode === "sync" ? 78 : 70,
        label: mode === "sync" ? "Great" : "Good",
        kind: mode === "sync" ? "personalized" : "general",
      },
      why:
        mode === "sync"
          ? ["Personalized scoring will be enabled once profile + AI hooks are connected."]
          : ["General estimate (Private mode)."],
      confidence: mode === "sync" ? 0.7 : 0.5,
    }));

    return res.json({
      meta: meta(req),
      data: { ranked },
    });
  });

  return router;
}


export function syncEatOutRouter() {
  const router = express.Router();

  router.post("/menu/ingest", requireSyncMode(), (req, res) => {
    // Accept menu_url | menu_text | upload_id | items[]
    // Return normalized menu + parseConfidence
  });

  router.post("/menu/score", requireSyncMode(), (req, res) => {
    // Accept normalized items
    // Return ranked items + confidence + explanations + safe fallback
  });

  return router;
}